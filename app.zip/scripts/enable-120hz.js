const fs = require('fs');
const path = require('path');

const mainActivityPath = path.join(
  __dirname, '..', 'android', 'app', 'src', 'main', 'java', 'com', 'olart', 'amaster', 'MainActivity.java'
);

const mainActivityCode = `package com.olart.amaster;

import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableHighRefreshRate();
        initNativeTTS();
    }

    private void initNativeTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(new Locale("si", "LK"));
                tts.setSpeechRate(0.93f);
            }
        });

        if (this.bridge != null && this.bridge.getWebView() != null) {
            this.bridge.getWebView().addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void speak(String text) {
                    speakLang(text, "si-LK");
                }

                @JavascriptInterface
                public void speakLang(String text, String langTag) {
                    if (tts != null && ttsReady) {
                        tts.stop();
                        Locale loc = "en-GB".equals(langTag) ? Locale.UK
                                   : "en-US".equals(langTag) ? Locale.US
                                   : new Locale("si", "LK");
                        int res = tts.setLanguage(loc);
                        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(Locale.getDefault());
                        }
                        tts.setSpeechRate(0.93f);
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "olart_tts");
                    }
                }

                @JavascriptInterface
                public void stop() {
                    if (tts != null) tts.stop();
                }
            }, "AndroidTTS");
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void enableHighRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display display = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    ? getDisplay()
                    : getWindowManager().getDefaultDisplay();
                if (display != null) {
                    Display.Mode[] modes = display.getSupportedModes();
                    Display.Mode bestMode = null;
                    float maxRefreshRate = 60.0f;
                    for (Display.Mode mode : modes) {
                        if (mode.getRefreshRate() > maxRefreshRate) {
                            maxRefreshRate = mode.getRefreshRate();
                            bestMode = mode;
                        }
                    }
                    WindowManager.LayoutParams params = getWindow().getAttributes();
                    if (bestMode != null) params.preferredDisplayModeId = bestMode.getModeId();
                    params.preferredRefreshRate = maxRefreshRate;
                    getWindow().setAttributes(params);
                }
            }
        } catch (Exception ignored) {}
    }
}
`;

if (fs.existsSync(mainActivityPath)) {
  fs.writeFileSync(mainActivityPath, mainActivityCode, 'utf8');
  console.log('Patched MainActivity.java for 120Hz + Sinhala Native TTS!');
}

const manifestPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android:hardwareAccelerated="true"')) {
    manifest = manifest.replace('<application', '<application android:hardwareAccelerated="true"');
    fs.writeFileSync(manifestPath, manifest, 'utf8');
  }
}

const customIconSrc = path.join(__dirname, '..', 'assets', 'icon.png');
const resDir = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');
if (fs.existsSync(customIconSrc) && fs.existsSync(resDir)) {
  for (const entry of fs.readdirSync(resDir)) {
    if (entry.startsWith('mipmap-anydpi')) {
      fs.rmSync(path.join(resDir, entry), { recursive: true, force: true });
    }
  }
  const mipmaps = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
  for (const folder of mipmaps) {
    const dirPath = path.join(resDir, folder);
    fs.mkdirSync(dirPath, { recursive: true });
    for (const f of fs.readdirSync(dirPath)) {
      if (f.startsWith('ic_launcher')) fs.unlinkSync(path.join(dirPath, f));
    }
    fs.copyFileSync(customIconSrc, path.join(dirPath, 'ic_launcher.png'));
    fs.copyFileSync(customIconSrc, path.join(dirPath, 'ic_launcher_round.png'));
  }
  console.log('Installed custom Art A+ Icon!');
}
